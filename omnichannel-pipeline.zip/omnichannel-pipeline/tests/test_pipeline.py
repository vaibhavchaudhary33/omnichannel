"""
tests/test_pipeline.py
Unit tests for cleaning utilities, deduplicator, and transformer.
"""
import pytest
import pandas as pd
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.transformation.cleaner import (
    clean_email, clean_phone, clean_name, parse_date,
    clean_float, clean_int, clean_bool, split_full_name,
)
from src.transformation.deduplicator import deduplicate


# ── Cleaner tests ─────────────────────────────────────────────────────────────

class TestCleanEmail:
    def test_valid_lowercase(self):
        assert clean_email("User@Example.COM") == "user@example.com"

    def test_strips_whitespace(self):
        assert clean_email("  hello@world.io  ") == "hello@world.io"

    def test_invalid_returns_none(self):
        assert clean_email("not-an-email") is None

    def test_empty_returns_none(self):
        assert clean_email("") is None
        assert clean_email(None) is None
        assert clean_email("nan") is None


class TestCleanPhone:
    def test_ten_digits(self):
        assert clean_phone("5551234567") == "+15551234567"

    def test_formatted_us(self):
        assert clean_phone("(555) 123-4567") == "+15551234567"

    def test_e164(self):
        assert clean_phone("+15551234567") == "+15551234567"

    def test_with_country_code(self):
        assert clean_phone("1-555-123-4567") == "+15551234567"

    def test_empty_returns_none(self):
        assert clean_phone(None) is None
        assert clean_phone("") is None

    def test_too_short_returns_none(self):
        assert clean_phone("123") is None


class TestCleanName:
    def test_title_case(self):
        assert clean_name("JOHN DOE") == "John Doe"
        assert clean_name("jane smith") == "Jane Smith"

    def test_strips_extra_spaces(self):
        assert clean_name("  Alice   ") == "Alice"

    def test_none_returns_none(self):
        assert clean_name(None) is None
        assert clean_name("") is None


class TestParseDate:
    def test_iso(self):
        assert parse_date("2023-07-15") == "2023-07-15"

    def test_us_format(self):
        assert parse_date("07/15/2023") == "2023-07-15"

    def test_eu_format(self):
        assert parse_date("15-07-2023") == "2023-07-15"

    def test_long_format(self):
        assert parse_date("July 15, 2023") == "2023-07-15"

    def test_unknown_returns_none(self):
        assert parse_date("not-a-date") is None

    def test_empty_returns_none(self):
        assert parse_date(None) is None


class TestCleanFloat:
    def test_plain_number(self):
        assert clean_float("123.45") == 123.45

    def test_currency_string(self):
        assert clean_float("$1,234.56") == 1234.56

    def test_none_default(self):
        assert clean_float(None) == 0.0

    def test_custom_default(self):
        assert clean_float(None, default=-1.0) == -1.0


class TestCleanBool:
    def test_truthy(self):
        for v in ("true", "1", "yes", "y", True, 1):
            assert clean_bool(v) is True

    def test_falsy(self):
        for v in ("false", "0", "no", "n", False, 0):
            assert clean_bool(v) is False

    def test_none(self):
        assert clean_bool(None) is None


class TestSplitFullName:
    def test_standard(self):
        assert split_full_name("John Smith") == ("John", "Smith")

    def test_comma_format(self):
        first, last = split_full_name("Smith, John")
        assert first == "John"
        assert last == "Smith"

    def test_single_name(self):
        first, last = split_full_name("Madonna")
        assert first == "Madonna"
        assert last is None

    def test_empty(self):
        assert split_full_name("") == (None, None)


# ── Deduplicator tests ────────────────────────────────────────────────────────

def _make_row(**kwargs) -> dict:
    defaults = {
        "email": None, "phone": None,
        "first_name": None, "last_name": None, "date_of_birth": None,
        "total_orders": 0, "total_spend": 0.0,
        "loyalty_points": 0, "loyalty_tier": None,
        "last_purchase_date": None, "tags": [], "source_ids": {},
    }
    defaults.update(kwargs)
    return defaults


class TestDeduplicator:
    def test_merges_by_email(self):
        rows = [
            _make_row(email="alice@x.com", total_orders=3, total_spend=100.0,
                      source_ids={"shopify_id": "S1"}),
            _make_row(email="alice@x.com", total_orders=2, total_spend=50.0,
                      loyalty_points=500, source_ids={"loyalty_id": "L1"}),
        ]
        df = deduplicate(pd.DataFrame(rows))
        assert len(df) == 1
        assert df.iloc[0]["total_orders"] == 5
        assert df.iloc[0]["total_spend"] == 150.0
        assert df.iloc[0]["loyalty_points"] == 500

    def test_no_duplicate_keeps_both(self):
        rows = [
            _make_row(email="alice@x.com", total_orders=1),
            _make_row(email="bob@x.com",   total_orders=2),
        ]
        df = deduplicate(pd.DataFrame(rows))
        assert len(df) == 2

    def test_coalesces_non_null_fields(self):
        rows = [
            _make_row(email="test@x.com", first_name="Alice", last_name=None),
            _make_row(email="test@x.com", first_name=None,    last_name="Smith"),
        ]
        df = deduplicate(pd.DataFrame(rows))
        assert df.iloc[0]["first_name"] == "Alice"
        assert df.iloc[0]["last_name"]  == "Smith"

    def test_most_recent_date_survives(self):
        rows = [
            _make_row(email="x@x.com", last_purchase_date="2022-01-01"),
            _make_row(email="x@x.com", last_purchase_date="2024-06-15"),
        ]
        df = deduplicate(pd.DataFrame(rows))
        assert df.iloc[0]["last_purchase_date"] == "2024-06-15"

    def test_merges_tags(self):
        rows = [
            _make_row(email="x@x.com", tags=["vip", "newsletter"]),
            _make_row(email="x@x.com", tags=["returning"]),
        ]
        df = deduplicate(pd.DataFrame(rows))
        assert set(df.iloc[0]["tags"]) == {"newsletter", "returning", "vip"}

    def test_unified_id_assigned(self):
        rows = [_make_row(email="z@z.com")]
        df   = deduplicate(pd.DataFrame(rows))
        uid  = df.iloc[0]["unified_id"]
        assert uid and len(uid) == 36  # UUID format


# ── Integration smoke test ────────────────────────────────────────────────────

class TestTransformerSmoke:
    def test_empty_inputs_return_empty_df(self):
        from src.transformation.transformer import Transformer, CANONICAL_COLS
        t  = Transformer(
            shopify_customers=pd.DataFrame(),
            shopify_orders=pd.DataFrame(),
            pos_df=pd.DataFrame(),
            loyalty_df=pd.DataFrame(),
        )
        result = t.run()
        assert set(CANONICAL_COLS).issubset(set(result.columns))
        assert len(result) == 0

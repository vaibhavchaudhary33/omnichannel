# Omnichannel Data Ingestion Engine
### A CDP Data Pipeline: ERP → PoS → CRM → Unified Customer Profile

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                     DATA SOURCES (Mock)                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │  Shopify API │  │  PoS CSV     │  │  Loyalty Program API │  │
│  │  (ERP/Orders)│  │  (Purchases) │  │  (CRM/Loyalty)       │  │
│  └──────┬───────┘  └──────┬───────┘  └──────────┬───────────┘  │
└─────────┼─────────────────┼────────────────────-─┼─────────────┘
          │                 │                       │
          ▼                 ▼                       ▼
┌─────────────────────────────────────────────────────────────────┐
│                   INGESTION LAYER                               │
│   REST API Fetcher     CSV Parser      API Fetcher              │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                 TRANSFORMATION LAYER                            │
│  ✦ Schema normalization    ✦ Date standardization              │
│  ✦ Missing field imputation ✦ Duplicate profile merging        │
│  ✦ Email/phone canonicalization ✦ Customer ID stitching        │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                    OUTPUT LAYER                                 │
│         AWS S3 Bucket  ──OR──  Local MySQL Database            │
│              Unified Customer Profile (CDP-ready)              │
└─────────────────────────────────────────────────────────────────┘
```

## Project Structure

```
omnichannel-pipeline/
├── config/
│   └── settings.py          # Env-based configuration
├── mock_servers/
│   ├── shopify_mock.py       # Flask mock for Shopify REST API
│   └── loyalty_mock.py       # Flask mock for Loyalty Program API
├── data/
│   ├── raw/                  # Raw ingested data (JSON/CSV)
│   └── processed/            # Cleaned output files
├── src/
│   ├── ingestion/
│   │   ├── shopify_ingestor.py    # Shopify API client
│   │   ├── pos_ingestor.py        # PoS CSV parser
│   │   └── loyalty_ingestor.py    # Loyalty API client
│   ├── transformation/
│   │   ├── cleaner.py             # Field cleaning utilities
│   │   ├── deduplicator.py        # Profile merging logic
│   │   └── transformer.py         # Main orchestration
│   └── output/
│       ├── s3_uploader.py         # AWS S3 writer
│       └── mysql_writer.py        # MySQL writer
├── tests/
│   └── test_pipeline.py           # Unit tests
├── pipeline.py               # Main entry point
├── generate_mock_data.py     # Seed script for mock data
└── requirements.txt
```

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Generate mock data
python generate_mock_data.py

# 3. Start mock API servers (in separate terminals)
python mock_servers/shopify_mock.py    # runs on :5001
python mock_servers/loyalty_mock.py   # runs on :5002

# 4. Run the full pipeline
python pipeline.py

# 5. (Optional) Run to MySQL instead of S3
python pipeline.py --output mysql

# 6. Run tests
pytest tests/
```

## Configuration

Copy `.env.example` to `.env` and fill in values:

```env
# AWS (optional — defaults to local file output)
AWS_ACCESS_KEY_ID=your_key
AWS_SECRET_ACCESS_KEY=your_secret
AWS_BUCKET_NAME=your-cdp-bucket
AWS_REGION=us-east-1

# MySQL (optional)
MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=password
MYSQL_DB=cdp

# API endpoints
SHOPIFY_API_URL=http://localhost:5001
LOYALTY_API_URL=http://localhost:5002
POS_CSV_PATH=data/raw/pos_transactions.csv
```

## Data Model: Unified Customer Profile

| Field | Type | Source |
|---|---|---|
| `unified_id` | UUID | Generated |
| `email` | str | All sources (canonical) |
| `phone` | str | Shopify + Loyalty |
| `first_name` | str | All sources |
| `last_name` | str | All sources |
| `date_of_birth` | date | Loyalty |
| `total_orders` | int | Shopify + PoS |
| `total_spend` | float | Shopify + PoS |
| `loyalty_points` | int | Loyalty |
| `loyalty_tier` | str | Loyalty |
| `last_purchase_date` | datetime | All sources |
| `tags` | list | Shopify |
| `source_ids` | dict | All sources |
| `created_at` | datetime | Pipeline |
